import java.util.Scanner;

/**
 * ╔══════════════════════════════════════════════════════╗
 * ║        SISTEMA DE GESTÃO - FAZENDA ESPERANÇA          ║
 * ║                                                        ║
 * ║  Disciplina: Desenvolvimento de Programas Estruturados ║
 * ║  Linguagem : Java                                      ║
 * ╚══════════════════════════════════════════════════════╝
 *
 * CLASSE: Main
 *
 * Ponto de entrada do sistema. Responsável por:
 *  1. Declarar todos os arrays que guardam os dados em memória
 *  2. Carregar os dados salvos nos arquivos .txt ao iniciar
 *  3. Exibir o menu principal em loop
 *  4. Direcionar para os submenus conforme a escolha do usuário
 *
 * ESTRUTURA DE DADOS:
 *  Cada entidade usa DOIS elementos:
 *  - Um array (ex: Funcionario[] funcionarios) com capacidade para 100 itens
 *  - Um int[] de 1 posição (ex: int[] totalFunc) que faz o papel de contador
 *
 *  Por que int[] em vez de int simples?
 *  → Em Java, tipos primitivos (int) são passados por VALOR para métodos,
 *    ou seja, a alteração dentro do método não reflete fora.
 *    Usando um array de 1 posição (int[]), passamos a REFERÊNCIA,
 *    permitindo que o método incremente o contador corretamente.
 */
public class Main {

    // -------------------------------------------------------
    // CAPACIDADE MÁXIMA DE CADA TIPO DE DADO
    // -------------------------------------------------------
    static final int MAX_REGISTROS = 100;

    public static void main(String[] args) {

        // ── DECLARAÇÃO DOS ARRAYS (memória do sistema) ────────────
        Funcionario[] funcionarios = new Funcionario[MAX_REGISTROS];
        Talhao[]      talhoes      = new Talhao[MAX_REGISTROS];
        Trator[]      frota        = new Trator[MAX_REGISTROS];
        Colheita[]    colheitas    = new Colheita[MAX_REGISTROS];

        // ── CONTADORES (int[] para permitir passagem por referência) ─
        int[] totalFunc       = {0}; // totalFunc[0] = quantidade de funcionários
        int[] totalTalhoes    = {0};
        int[] totalFrota      = {0};
        int[] totalColheitas  = {0};

        // ── CARREGAMENTO DOS DADOS SALVOS ─────────────────────────
        System.out.println("Carregando dados salvos...");
        Arquivos.carregarFuncionarios(funcionarios, totalFunc);
        Arquivos.carregarTalhoes(talhoes, totalTalhoes);
        Arquivos.carregarFrota(frota, totalFrota);
        Arquivos.carregarColheitas(colheitas, totalColheitas);

        System.out.println("  → " + totalFunc[0]      + " funcionário(s) carregado(s)");
        System.out.println("  → " + totalTalhoes[0]   + " talhão(ões) carregado(s)");
        System.out.println("  → " + totalFrota[0]     + " trator(es) carregado(s)");
        System.out.println("  → " + totalColheitas[0] + " colheita(s) carregada(s)");

        // ── SCANNER (único, compartilhado por todo o sistema) ─────
        Scanner sc = new Scanner(System.in);

        // ── MENU PRINCIPAL ────────────────────────────────────────
        int opcao;

        do {
            exibirMenuPrincipal();
            System.out.print("Opção: ");

            opcao = sc.nextInt();
            sc.nextLine(); // limpa o \n que sobra no buffer

            switch (opcao) {
                case 1:
                    // Vai para o submenu de Funcionários
                    GerenciadorFuncionarios.menuFuncionarios(funcionarios, totalFunc, sc);
                    break;

                case 2:
                    // Vai para o submenu de Talhões
                    GerenciadorTalhoes.menuTalhoes(talhoes, totalTalhoes, sc);
                    break;

                case 3:
                    // Vai para o submenu de Frota
                    GerenciadorFrota.menuFrota(frota, totalFrota, sc);
                    break;

                case 4:
                    // Vai para o submenu de Colheitas
                    // Passa TODOS os arrays pois precisa validar funcionário, talhão e trator
                    GerenciadorColheitas.menuColheitas(
                            colheitas,    totalColheitas,
                            funcionarios, totalFunc,
                            talhoes,      totalTalhoes,
                            frota,        totalFrota,
                            sc
                    );
                    break;

                case 5:
                    // Vai para os Relatórios
                    Relatorios.menuRelatorios(
                            colheitas,    totalColheitas[0],
                            funcionarios, totalFunc[0],
                            talhoes,      totalTalhoes[0]
                    );
                    break;

                case 0:
                    System.out.println("\nEncerrando o sistema...");
                    System.out.println("Dados salvos com sucesso. Até logo!");
                    break;

                default:
                    System.out.println("Opção inválida! Digite um número entre 0 e 5.");
            }

        } while (opcao != 0); // fica no loop até o usuário escolher sair

        sc.close(); // fecha o Scanner ao encerrar
    }

    /**
     * Exibe o menu principal do sistema.
     * Separado em método próprio para manter o main() limpo e organizado.
     */
    public static void exibirMenuPrincipal() {
        System.out.println("\n");
        System.out.println("╔═══════════════════════════════════════╗");
        System.out.println("║   🌱 FAZENDA ESPERANÇA - SISTEMA       ║");
        System.out.println("╠═══════════════════════════════════════╣");
        System.out.println("║  1 - Gestão de Funcionários            ║");
        System.out.println("║  2 - Gestão de Talhões                 ║");
        System.out.println("║  3 - Gestão da Frota                   ║");
        System.out.println("║  4 - Registro de Colheita              ║");
        System.out.println("║  5 - Relatórios                        ║");
        System.out.println("║  0 - Sair do Sistema                   ║");
        System.out.println("╚═══════════════════════════════════════╝");
    }
}