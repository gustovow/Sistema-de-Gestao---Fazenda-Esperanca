import java.io.*;

/**
 * CLASSE: Arquivos
 *
 * Responsável por toda a leitura e escrita em arquivos .txt.
 *
 * Cada entidade tem seu próprio arquivo:
 *   - funcionarios.txt
 *   - talhoes.txt
 *   - frota.txt
 *   - colheitas.txt
 *
 * Formato de cada linha: campos separados por ponto e vírgula ";"
 * Exemplo: João Silva;1001;Fixo
 *
 * ESTRATÉGIA:
 *   - Ao cadastrar algo → ADICIONA uma linha no final do arquivo (append)
 *   - Ao carregar       → LÊ linha por linha e reconstrói os arrays
 */
public class Arquivos {

    // -------------------------------------------------------
    // NOMES DOS ARQUIVOS (constantes para evitar erros de digitação)
    // -------------------------------------------------------
    static final String ARQUIVO_FUNCIONARIOS = "funcionarios.txt";
    static final String ARQUIVO_TALHOES      = "talhoes.txt";
    static final String ARQUIVO_FROTA        = "frota.txt";
    static final String ARQUIVO_COLHEITAS    = "colheitas.txt";

    // ================================================================
    // MÉTODOS DE SALVAMENTO (append = adicionar no final do arquivo)
    // ================================================================

    /**
     * Salva um funcionário no arquivo funcionarios.txt
     * Adiciona uma nova linha ao final do arquivo existente.
     */
    public static void salvarFuncionario(Funcionario f) {
        try {
            // "true" no FileWriter significa APPEND (não apaga o conteúdo existente)
            FileWriter fw = new FileWriter(ARQUIVO_FUNCIONARIOS, true);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(f.paraTexto()); // escreve: nome;matricula;tipo
            bw.newLine();            // pula para a próxima linha

            bw.close();
        } catch (IOException e) {
            System.out.println("Erro ao salvar funcionário: " + e.getMessage());
        }
    }

    /**
     * Salva um talhão no arquivo talhoes.txt
     */
    public static void salvarTalhao(Talhao t) {
        try {
            FileWriter fw = new FileWriter(ARQUIVO_TALHOES, true);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(t.paraTexto()); // codigo;nome;variedade;estimativa
            bw.newLine();

            bw.close();
        } catch (IOException e) {
            System.out.println("Erro ao salvar talhão: " + e.getMessage());
        }
    }

    /**
     * Salva um trator no arquivo frota.txt
     */
    public static void salvarTrator(Trator t) {
        try {
            FileWriter fw = new FileWriter(ARQUIVO_FROTA, true);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(t.paraTexto()); // placa;capacidade
            bw.newLine();

            bw.close();
        } catch (IOException e) {
            System.out.println("Erro ao salvar trator: " + e.getMessage());
        }
    }

    /**
     * Salva um registro de colheita no arquivo colheitas.txt
     */
    public static void salvarColheita(Colheita c) {
        try {
            FileWriter fw = new FileWriter(ARQUIVO_COLHEITAS, true);
            BufferedWriter bw = new BufferedWriter(fw);

            bw.write(c.paraTexto()); // data;matricula;talhao;placa;litros;local
            bw.newLine();

            bw.close();
        } catch (IOException e) {
            System.out.println("Erro ao salvar colheita: " + e.getMessage());
        }
    }

    // ================================================================
    // MÉTODOS DE CARREGAMENTO (lê arquivo e preenche os arrays)
    // ================================================================

    /**
     * Lê funcionarios.txt e preenche o array de funcionários.
     *
     * @param funcionarios array onde os dados serão carregados
     * @param contador     array de 1 posição usado como contador (passa por referência)
     */
    public static void carregarFuncionarios(Funcionario[] funcionarios, int[] contador) {
        try {
            FileReader fr = new FileReader(ARQUIVO_FUNCIONARIOS);
            BufferedReader br = new BufferedReader(fr);

            String linha;

            // Lê linha por linha até o final do arquivo (null = fim)
            while ((linha = br.readLine()) != null) {
                linha = linha.trim(); // remove espaços extras

                // Ignora linhas vazias
                if (linha.isEmpty()) continue;

                // Divide a linha pelo separador ";"
                // Exemplo: "João;1001;Fixo" → ["João", "1001", "Fixo"]
                String[] partes = linha.split(";");

                if (partes.length == 3) {
                    // Reconstrói o objeto Funcionario com os dados lidos
                    funcionarios[contador[0]] = new Funcionario(partes[0], partes[1], partes[2]);
                    contador[0]++; // incrementa o contador
                }
            }

            br.close();

        } catch (FileNotFoundException e) {
            // Arquivo ainda não existe (primeira execução) — sem problema, começa vazio
        } catch (IOException e) {
            System.out.println("Erro ao carregar funcionários: " + e.getMessage());
        }
    }

    /**
     * Lê talhoes.txt e preenche o array de talhões.
     */
    public static void carregarTalhoes(Talhao[] talhoes, int[] contador) {
        try {
            FileReader fr = new FileReader(ARQUIVO_TALHOES);
            BufferedReader br = new BufferedReader(fr);

            String linha;

            while ((linha = br.readLine()) != null) {
                linha = linha.trim();
                if (linha.isEmpty()) continue;

                String[] partes = linha.split(";");

                if (partes.length == 4) {
                    // partes[3] é a estimativa em litros → converte String para double
                    double estimativa = Double.parseDouble(partes[3]);
                    talhoes[contador[0]] = new Talhao(partes[0], partes[1], partes[2], estimativa);
                    contador[0]++;
                }
            }

            br.close();

        } catch (FileNotFoundException e) {
            // Arquivo não existe ainda — normal na primeira execução
        } catch (IOException e) {
            System.out.println("Erro ao carregar talhões: " + e.getMessage());
        }
    }

    /**
     * Lê frota.txt e preenche o array de tratores.
     */
    public static void carregarFrota(Trator[] frota, int[] contador) {
        try {
            FileReader fr = new FileReader(ARQUIVO_FROTA);
            BufferedReader br = new BufferedReader(fr);

            String linha;

            while ((linha = br.readLine()) != null) {
                linha = linha.trim();
                if (linha.isEmpty()) continue;

                String[] partes = linha.split(";");

                if (partes.length == 2) {
                    double capacidade = Double.parseDouble(partes[1]);
                    frota[contador[0]] = new Trator(partes[0], capacidade);
                    contador[0]++;
                }
            }

            br.close();

        } catch (FileNotFoundException e) {
            // Arquivo ainda não existe
        } catch (IOException e) {
            System.out.println("Erro ao carregar frota: " + e.getMessage());
        }
    }

    /**
     * Lê colheitas.txt e preenche o array de colheitas.
     */
    public static void carregarColheitas(Colheita[] colheitas, int[] contador) {
        try {
            FileReader fr = new FileReader(ARQUIVO_COLHEITAS);
            BufferedReader br = new BufferedReader(fr);

            String linha;

            while ((linha = br.readLine()) != null) {
                linha = linha.trim();
                if (linha.isEmpty()) continue;

                String[] partes = linha.split(";");

                if (partes.length == 6) {
                    double litros = Double.parseDouble(partes[4]);
                    colheitas[contador[0]] = new Colheita(
                            partes[0], // data
                            partes[1], // matricula
                            partes[2], // codigo talhao
                            partes[3], // placa
                            litros,    // quantidade
                            partes[5]  // local
                    );
                    contador[0]++;
                }
            }

            br.close();

        } catch (FileNotFoundException e) {
            // Arquivo ainda não existe
        } catch (IOException e) {
            System.out.println("Erro ao carregar colheitas: " + e.getMessage());
        }
    }
}