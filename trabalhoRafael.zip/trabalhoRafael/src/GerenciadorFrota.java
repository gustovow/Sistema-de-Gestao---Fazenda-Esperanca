import java.util.Scanner;

/**
 * CLASSE: GerenciadorFrota
 *
 * Contém todos os métodos relacionados ao cadastro e consulta da frota de tratores.
 *
 * Responsabilidades:
 *  - Exibir o menu de frota
 *  - Cadastrar novo trator (com validação de placa duplicada)
 *  - Listar todos os tratores
 *  - Buscar um trator pela placa (usado nas validações de colheita)
 */
public class GerenciadorFrota {

    /**
     * Exibe o submenu de Frota e processa a escolha do usuário.
     */
    public static void menuFrota(Trator[] frota, int[] totalFrota, Scanner sc) {
        int opcao;

        do {
            System.out.println("\n╔══════════════════════════════╗");
            System.out.println("║        GESTÃO DA FROTA        ║");
            System.out.println("╠══════════════════════════════╣");
            System.out.println("║ 1 - Cadastrar Trator          ║");
            System.out.println("║ 2 - Listar Frota              ║");
            System.out.println("║ 0 - Voltar ao Menu Principal  ║");
            System.out.println("╚══════════════════════════════╝");
            System.out.print("Opção: ");

            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarTrator(frota, totalFrota, sc);
                    break;
                case 2:
                    listarFrota(frota, totalFrota[0]);
                    break;
                case 0:
                    System.out.println("Voltando ao menu principal...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }

        } while (opcao != 0);
    }

    /**
     * Cadastra um novo trator na frota.
     *
     * Validações:
     *  - Não permite placa duplicada
     *  - Capacidade deve ser maior que zero
     */
    public static void cadastrarTrator(Trator[] frota, int[] totalFrota, Scanner sc) {

        if (totalFrota[0] >= frota.length) {
            System.out.println("Limite de tratores atingido!");
            return;
        }

        System.out.println("\n--- CADASTRO DE TRATOR ---");

        System.out.print("Placa do trator (ex: ABC-1234): ");
        String placa = sc.nextLine().trim().toUpperCase();

        // Verifica se a placa já está cadastrada
        if (buscarTrator(frota, totalFrota[0], placa) != null) {
            System.out.println("ERRO: Já existe um trator com essa placa!");
            return;
        }

        System.out.print("Capacidade máxima da carreta (litros): ");
        double capacidade = sc.nextDouble();
        sc.nextLine();

        if (capacidade <= 0) {
            System.out.println("ERRO: A capacidade deve ser maior que zero!");
            return;
        }

        // Cria e armazena o novo trator
        Trator novo = new Trator(placa, capacidade);
        frota[totalFrota[0]] = novo;
        totalFrota[0]++;

        // Persiste no arquivo
        Arquivos.salvarTrator(novo);

        System.out.println("✔ Trator cadastrado com sucesso!");
    }

    /**
     * Lista todos os tratores cadastrados.
     */
    public static void listarFrota(Trator[] frota, int totalFrota) {
        System.out.println("\n--- LISTA DA FROTA ---");

        if (totalFrota == 0) {
            System.out.println("Nenhum trator cadastrado.");
            return;
        }

        System.out.printf("%-5s %-15s %15s%n", "Nº", "Placa", "Capacidade (L)");
        System.out.println("─".repeat(38));

        for (int i = 0; i < totalFrota; i++) {
            System.out.printf("%-5d %-15s %15.2f%n",
                    (i + 1),
                    frota[i].placa,
                    frota[i].capacidadeLitros
            );
        }
    }

    /**
     * Busca um trator pela placa.
     *
     * @param frota      array de tratores
     * @param totalFrota quantidade de tratores no array
     * @param placa      placa que se deseja encontrar
     * @return Trator encontrado, ou null
     */
    public static Trator buscarTrator(Trator[] frota, int totalFrota, String placa) {
        for (int i = 0; i < totalFrota; i++) {
            if (frota[i].placa.equalsIgnoreCase(placa)) {
                return frota[i];
            }
        }
        return null;
    }
}