package Servico;

import Modelo.Colheita;
import Modelo.Funcionario;
import Modelo.Talhao;
import Modelo.Trator;

import java.util.Scanner;

/**
 * CLASSE: Servico.GerenciadorColheitas
 *
 * Responsável por registrar e listar colheitas.
 *
 * VALIDAÇÕES OBRIGATÓRIAS (aplicadas antes de registrar):
 *  1. Funcionário deve existir (busca pela matrícula)
 *  2. Talhão deve existir (busca pelo código)
 *  3. Modelo.Trator deve existir (busca pela placa)
 *  4. Quantidade de litros NÃO pode ultrapassar a capacidade da carreta
 *
 * Se qualquer validação falhar, o registro é CANCELADO e o usuário é informado.
 */
public class GerenciadorColheitas {

    /**
     * Exibe o submenu de Colheitas e processa a escolha do usuário.
     *
     * Recebe todos os arrays necessários para as validações cruzadas.
     */
    public static void menuColheitas(
            Colheita[]    colheitas, int[] totalColheitas,
            Funcionario[] funcionarios, int[] totalFunc,
            Talhao[]      talhoes, int[] totalTalhoes,
            Trator[]      frota, int[] totalFrota,
            Scanner sc) {

        int opcao;

        do {
            System.out.println("\n╔══════════════════════════════╗");
            System.out.println("║     REGISTRO DE COLHEITA      ║");
            System.out.println("╠══════════════════════════════╣");
            System.out.println("║ 1 - Registrar Modelo.Colheita        ║");
            System.out.println("║ 2 - Listar Colheitas          ║");
            System.out.println("║ 0 - Voltar ao Menu Principal  ║");
            System.out.println("╚══════════════════════════════╝");
            System.out.print("Opção: ");

            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    registrarColheita(
                            colheitas, totalColheitas,
                            funcionarios, totalFunc[0],
                            talhoes, totalTalhoes[0],
                            frota, totalFrota[0],
                            sc
                    );
                    break;
                case 2:
                    listarColheitas(colheitas, totalColheitas[0]);
                    break;
                case 0:
                    System.out.println("Voltando ao menu principal...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }

        } while (opcao != 0);
    }

    /**
     * Registra uma nova colheita, aplicando todas as validações.
     */
    public static void registrarColheita(
            Colheita[]    colheitas, int[] totalColheitas,
            Funcionario[] funcionarios, int totalFunc,
            Talhao[]      talhoes, int totalTalhoes,
            Trator[]      frota, int totalFrota,
            Scanner sc) {

        if (totalColheitas[0] >= colheitas.length) {
            System.out.println("Limite de registros de colheita atingido!");
            return;
        }

        System.out.println("\n--- REGISTRO DE COLHEITA ---");

        // ── DATA ──────────────────────────────────────────────────
        System.out.print("Data da colheita (dd/mm/aaaa): ");
        String data = sc.nextLine().trim();

        // ── FUNCIONÁRIO ───────────────────────────────────────────
        System.out.print("Matrícula do funcionário: ");
        String matricula = sc.nextLine().trim();

        // VALIDAÇÃO 1: funcionário deve existir
        Funcionario func = GerenciadorFuncionarios.buscarFuncionario(funcionarios, totalFunc, matricula);
        if (func == null) {
            System.out.println("ERRO: Funcionário com matrícula '" + matricula + "' não encontrado!");
            System.out.println("Cadastre o funcionário antes de registrar a colheita.");
            return; // cancela o registro
        }
        System.out.println("  → Funcionário: " + func.nome + " (" + func.tipoContrato + ")");

        // ── TALHÃO ────────────────────────────────────────────────
        System.out.print("Código do talhão: ");
        String codigoTalhao = sc.nextLine().trim().toUpperCase();

        // VALIDAÇÃO 2: talhão deve existir
        Talhao talhao = GerenciadorTalhoes.buscarTalhao(talhoes, totalTalhoes, codigoTalhao);
        if (talhao == null) {
            System.out.println("ERRO: Talhão com código '" + codigoTalhao + "' não encontrado!");
            System.out.println("Cadastre o talhão antes de registrar a colheita.");
            return;
        }
        System.out.println("  → Talhão: " + talhao.nome + " | Variedade: " + talhao.variedadeCafe);

        // ── TRATOR ────────────────────────────────────────────────
        System.out.print("Placa do trator: ");
        String placa = sc.nextLine().trim().toUpperCase();

        // VALIDAÇÃO 3: trator deve existir
        Trator trator = GerenciadorFrota.buscarTrator(frota, totalFrota, placa);
        if (trator == null) {
            System.out.println("ERRO: Modelo.Trator com placa '" + placa + "' não encontrado!");
            System.out.println("Cadastre o trator antes de registrar a colheita.");
            return;
        }
        System.out.println("  → Modelo.Trator: " + trator.placa + " | Capacidade: " + trator.capacidadeLitros + "L");

        // ── QUANTIDADE ────────────────────────────────────────────
        System.out.print("Quantidade colhida (litros): ");
        double quantidade = sc.nextDouble();
        sc.nextLine();

        // VALIDAÇÃO 4: quantidade não pode ultrapassar capacidade da carreta
        if (quantidade > trator.capacidadeLitros) {
            System.out.println("ERRO: Quantidade (" + quantidade + "L) ultrapassa a capacidade");
            System.out.println("       da carreta (" + trator.capacidadeLitros + "L)!");
            return;
        }

        if (quantidade <= 0) {
            System.out.println("ERRO: Quantidade deve ser maior que zero!");
            return;
        }

        // ── LOCAL DE DESCARREGAMENTO ──────────────────────────────
        System.out.println("Local de descarregamento:");
        System.out.println("  1 - Terreiro de Cimento");
        System.out.println("  2 - Secador Mecânico");
        System.out.print("Escolha: ");
        int localEscolha = sc.nextInt();
        sc.nextLine();

        String local;
        if (localEscolha == 1) {
            local = "Terreiro de Cimento";
        } else if (localEscolha == 2) {
            local = "Secador Mecânico";
        } else {
            System.out.println("ERRO: Local de descarregamento inválido!");
            return;
        }

        // ── SALVA O REGISTRO ──────────────────────────────────────
        Colheita nova = new Colheita(data, matricula, codigoTalhao, placa, quantidade, local);
        colheitas[totalColheitas[0]] = nova;
        totalColheitas[0]++;

        // Persiste no arquivo
        Arquivos.salvarColheita(nova);

        System.out.println("✔ Modelo.Colheita registrada com sucesso!");
        System.out.println("  Data: " + data + " | Funcionário: " + func.nome);
        System.out.println("  Talhão: " + talhao.nome + " | Litros: " + quantidade + " | Local: " + local);
    }

    /**
     * Lista todas as colheitas registradas.
     */
    public static void listarColheitas(Colheita[] colheitas, int totalColheitas) {
        System.out.println("\n--- LISTA DE COLHEITAS REGISTRADAS ---");

        if (totalColheitas == 0) {
            System.out.println("Nenhuma colheita registrada.");
            return;
        }

        System.out.printf("%-12s %-10s %-8s %-10s %10s %-22s%n",
                "Data", "Matrícula", "Talhão", "Placa", "Litros", "Local");
        System.out.println("─".repeat(77));

        for (int i = 0; i < totalColheitas; i++) {
            System.out.printf("%-12s %-10s %-8s %-10s %10.2f %-22s%n",
                    colheitas[i].data,
                    colheitas[i].matriculaFuncionario,
                    colheitas[i].codigoTalhao,
                    colheitas[i].placaTrator,
                    colheitas[i].quantidadeLitros,
                    colheitas[i].localDescarregamento
            );
        }
    }
}