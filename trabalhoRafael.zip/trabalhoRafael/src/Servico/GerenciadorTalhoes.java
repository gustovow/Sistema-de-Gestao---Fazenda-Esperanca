package Servico;

import Modelo.Talhao;

import java.util.Scanner;

/**
 * CLASSE: Servico.GerenciadorTalhoes
 *
 * Contém todos os métodos relacionados ao cadastro e consulta de talhões.
 *
 * Responsabilidades:
 *  - Exibir o menu de talhões
 *  - Cadastrar novo talhão (com validação de código duplicado)
 *  - Listar todos os talhões
 *  - Buscar um talhão pelo código (usado nas validações de colheita)
 */
public class GerenciadorTalhoes {

    /**
     * Exibe o submenu de Talhões e processa a escolha do usuário.
     */
    public static void menuTalhoes(Talhao[] talhoes, int[] totalTalhoes, Scanner sc) {
        int opcao;

        do {
            System.out.println("\n╔══════════════════════════════╗");
            System.out.println("║       GESTÃO DE TALHÕES       ║");
            System.out.println("╠══════════════════════════════╣");
            System.out.println("║ 1 - Cadastrar Talhão          ║");
            System.out.println("║ 2 - Listar Talhões            ║");
            System.out.println("║ 0 - Voltar ao Menu Principal  ║");
            System.out.println("╚══════════════════════════════╝");
            System.out.print("Opção: ");

            opcao = sc.nextInt();
            sc.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarTalhao(talhoes, totalTalhoes, sc);
                    break;
                case 2:
                    listarTalhoes(talhoes, totalTalhoes[0]);
                    break;
                case 0:
                    System.out.println("Voltando ao menu principal...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }

        } while (opcao != 0);
    }

    /**
     * Cadastra um novo talhão.
     *
     * Validações:
     *  - Não permite código duplicado
     *  - Estimativa de litros deve ser maior que zero
     */
    public static void cadastrarTalhao(Talhao[] talhoes, int[] totalTalhoes, Scanner sc) {

        if (totalTalhoes[0] >= talhoes.length) {
            System.out.println("Limite de talhões atingido!");
            return;
        }

        System.out.println("\n--- CADASTRO DE TALHÃO ---");

        System.out.print("Código do talhão (ex: T01): ");
        String codigo = sc.nextLine().trim().toUpperCase(); // converte para maiúsculas

        // Verifica duplicidade de código
        if (buscarTalhao(talhoes, totalTalhoes[0], codigo) != null) {
            System.out.println("ERRO: Já existe um talhão com esse código!");
            return;
        }

        System.out.print("Nome do talhão: ");
        String nome = sc.nextLine().trim();

        System.out.print("Variedade do café: ");
        String variedade = sc.nextLine().trim();

        System.out.print("Estimativa de produção (litros): ");
        double estimativa = sc.nextDouble();
        sc.nextLine();

        // Valida que a estimativa é positiva
        if (estimativa <= 0) {
            System.out.println("ERRO: A estimativa deve ser maior que zero!");
            return;
        }

        // Cria e armazena o novo talhão
        Talhao novo = new Talhao(codigo, nome, variedade, estimativa);
        talhoes[totalTalhoes[0]] = novo;
        totalTalhoes[0]++;

        // Persiste no arquivo
        Arquivos.salvarTalhao(novo);

        System.out.println("✔ Talhão cadastrado com sucesso!");
    }

    /**
     * Lista todos os talhões cadastrados em formato de tabela.
     */
    public static void listarTalhoes(Talhao[] talhoes, int totalTalhoes) {
        System.out.println("\n--- LISTA DE TALHÕES ---");

        if (totalTalhoes == 0) {
            System.out.println("Nenhum talhão cadastrado.");
            return;
        }

        System.out.printf("%-6s %-20s %-20s %12s%n", "Código", "Nome", "Variedade", "Estimativa(L)");
        System.out.println("─".repeat(62));

        for (int i = 0; i < totalTalhoes; i++) {
            System.out.printf("%-6s %-20s %-20s %12.2f%n",
                    talhoes[i].codigo,
                    talhoes[i].nome,
                    talhoes[i].variedadeCafe,
                    talhoes[i].estimativaLitros
            );
        }
    }

    /**
     * Busca um talhão pelo código.
     *
     * @param talhoes      array de talhões
     * @param totalTalhoes quantidade de talhões no array
     * @param codigo       código que se deseja encontrar
     * @return Modelo.Talhao encontrado, ou null
     */
    public static Talhao buscarTalhao(Talhao[] talhoes, int totalTalhoes, String codigo) {
        for (int i = 0; i < totalTalhoes; i++) {
            if (talhoes[i].codigo.equalsIgnoreCase(codigo)) {
                return talhoes[i];
            }
        }
        return null;
    }
}