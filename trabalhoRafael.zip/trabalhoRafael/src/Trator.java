/**
 * CLASSE: Trator
 *
 * Representa um veículo (trator com carreta) da frota da fazenda.
 *
 * Campos:
 *  - placa            : identificação do veículo (ex: "ABC-1234")
 *  - capacidadeLitros : volume máximo que a carreta suporta em litros
 */
public class Trator {

    // -------------------------------------------------------
    // ATRIBUTOS
    // -------------------------------------------------------
    String placa;
    double capacidadeLitros; // capacidade máxima da carreta em litros

    // -------------------------------------------------------
    // CONSTRUTOR
    // -------------------------------------------------------
    public Trator(String placa, double capacidadeLitros) {
        this.placa = placa;
        this.capacidadeLitros = capacidadeLitros;
    }

    /**
     * Converte o trator para linha de texto no formato:
     * placa;capacidadeLitros
     *
     * Usado para salvar no arquivo frota.txt
     */
    public String paraTexto() {
        return placa + ";" + capacidadeLitros;
    }
}