package Modelo;

/**
 * CLASSE: Modelo.Talhao
 *
 * Representa um talhão (área de plantio) da fazenda.
 *
 * Campos:
 *  - codigo            : identificador único do talhão (ex: "T01")
 *  - nome              : nome descritivo do talhão (ex: "Talhão Norte")
 *  - variedadeCafe     : tipo/variedade do café plantado
 *  - estimativaLitros  : produção esperada em litros para a safra
 */
public class Talhao {

    // -------------------------------------------------------
    // ATRIBUTOS
    // -------------------------------------------------------
    String codigo;
    String nome;
    String variedadeCafe;
    double estimativaLitros; // estimativa de produção em litros

    // -------------------------------------------------------
    // CONSTRUTOR
    // -------------------------------------------------------
    public Talhao(String codigo, String nome, String variedadeCafe, double estimativaLitros) {
        this.codigo = codigo;
        this.nome = nome;
        this.variedadeCafe = variedadeCafe;
        this.estimativaLitros = estimativaLitros;
    }

    /**
     * Converte o talhão para linha de texto no formato:
     * codigo;nome;variedadeCafe;estimativaLitros
     *
     * Usado para salvar no arquivo talhoes.txt
     */
    public String paraTexto() {
        return codigo + ";" + nome + ";" + variedadeCafe + ";" + estimativaLitros;
    }
}