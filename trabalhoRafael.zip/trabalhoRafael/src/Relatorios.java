/**
 * CLASSE: Relatorios
 *
 * Contém todos os relatórios do sistema da Fazenda Esperança.
 *
 * Relatórios disponíveis:
 *  A) Total de litros por funcionário
 *  B) Total produzido por talhão
 *  C) Comparação: produção atual vs estimativa (por talhão)
 *  D) Total enviado por local de descarregamento
 *
 * LÓGICA GERAL DE TODOS OS RELATÓRIOS:
 *  - Percorremos o array de colheitas com um for
 *  - Acumulamos/somamos os valores que nos interessam
 *  - Exibimos o resultado formatado
 *
 * IMPORTANTE: Não usamos HashMap nem coleções avançadas.
 * Para agrupar por funcionário ou talhão, usamos arrays paralelos:
 *  - Um array para os identificadores encontrados (ex: matrículas)
 *  - Um array para os totais acumulados correspondentes
 */
public class Relatorios {

    // Tamanho máximo de agrupamentos nos relatórios (100 grupos distintos)
    static final int MAX_GRUPOS = 100;

    /**
     * Exibe o menu de relatórios.
     */
    public static void menuRelatorios(
            Colheita[]    colheitas,    int totalColheitas,
            Funcionario[] funcionarios, int totalFunc,
            Talhao[]      talhoes,      int totalTalhoes) {

        // Verifica se há dados suficientes
        if (totalColheitas == 0) {
            System.out.println("\nNenhuma colheita registrada. Não há dados para relatórios.");
            return;
        }

        System.out.println("\n╔══════════════════════════════════════╗");
        System.out.println("║            RELATÓRIOS                 ║");
        System.out.println("╠══════════════════════════════════════╣");
        System.out.println("║ A - Litros por Funcionário            ║");
        System.out.println("║ B - Total Produzido por Talhão        ║");
        System.out.println("║ C - Produção Atual vs Estimativa      ║");
        System.out.println("║ D - Total por Local de Descarregamento║");
        System.out.println("║ T - Exibir TODOS os Relatórios        ║");
        System.out.println("║ 0 - Voltar ao Menu Principal          ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.print("Opção: ");

        // Lê a opção como caractere
        java.util.Scanner sc = new java.util.Scanner(System.in);
        String opcao = sc.nextLine().trim().toUpperCase();

        switch (opcao) {
            case "A":
                relatorioLitrosPorFuncionario(colheitas, totalColheitas, funcionarios, totalFunc);
                break;
            case "B":
                relatorioProducaoPorTalhao(colheitas, totalColheitas, talhoes, totalTalhoes);
                break;
            case "C":
                relatorioComparacaoEstimativa(colheitas, totalColheitas, talhoes, totalTalhoes);
                break;
            case "D":
                relatorioLocalDescarregamento(colheitas, totalColheitas);
                break;
            case "T":
                // Exibe todos os relatórios em sequência
                relatorioLitrosPorFuncionario(colheitas, totalColheitas, funcionarios, totalFunc);
                relatorioProducaoPorTalhao(colheitas, totalColheitas, talhoes, totalTalhoes);
                relatorioComparacaoEstimativa(colheitas, totalColheitas, talhoes, totalTalhoes);
                relatorioLocalDescarregamento(colheitas, totalColheitas);
                break;
            case "0":
                System.out.println("Voltando ao menu principal...");
                break;
            default:
                System.out.println("Opção inválida!");
        }
    }

    // ================================================================
    // RELATÓRIO A — Total de litros por funcionário
    // ================================================================

    /**
     * Calcula e exibe o total de litros colhidos por cada funcionário.
     *
     * ESTRATÉGIA:
     *  - Criamos dois arrays paralelos: 'matriculas' e 'totais'
     *  - Para cada colheita, procuramos se a matrícula já foi vista
     *  - Se sim, somamos ao total existente
     *  - Se não, adicionamos uma nova entrada
     */
    public static void relatorioLitrosPorFuncionario(
            Colheita[]    colheitas,   int totalColheitas,
            Funcionario[] funcionarios, int totalFunc) {

        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  RELATÓRIO A — Total de Litros por Funcionário");
        System.out.println("══════════════════════════════════════════════");

        // Arrays paralelos para acumular os totais
        String[] matriculasVistas = new String[MAX_GRUPOS];
        double[] totaisPorFunc    = new double[MAX_GRUPOS];
        int quantidadeGrupos = 0; // quantos funcionários distintos encontramos

        // Percorre todas as colheitas
        for (int i = 0; i < totalColheitas; i++) {
            String mat = colheitas[i].matriculaFuncionario;
            double litros = colheitas[i].quantidadeLitros;

            // Verifica se já vimos essa matrícula antes
            int posicao = encontrarPosicao(matriculasVistas, quantidadeGrupos, mat);

            if (posicao >= 0) {
                // Matrícula já existe: soma ao total
                totaisPorFunc[posicao] += litros;
            } else {
                // Nova matrícula: adiciona um novo grupo
                matriculasVistas[quantidadeGrupos] = mat;
                totaisPorFunc[quantidadeGrupos]    = litros;
                quantidadeGrupos++;
            }
        }

        // Exibe os resultados
        System.out.printf("%-12s %-25s %15s%n", "Matrícula", "Nome", "Total (L)");
        System.out.println("─".repeat(55));

        double totalGeral = 0;

        for (int i = 0; i < quantidadeGrupos; i++) {
            // Busca o nome do funcionário pela matrícula
            Funcionario f = GerenciadorFuncionarios.buscarFuncionario(
                    funcionarios, totalFunc, matriculasVistas[i]);

            String nomeFunc = (f != null) ? f.nome : "(desconhecido)";

            System.out.printf("%-12s %-25s %15.2f%n",
                    matriculasVistas[i], nomeFunc, totaisPorFunc[i]);

            totalGeral += totaisPorFunc[i];
        }

        System.out.println("─".repeat(55));
        System.out.printf("%-38s %15.2f%n", "TOTAL GERAL:", totalGeral);
    }

    // ================================================================
    // RELATÓRIO B — Total produzido por talhão
    // ================================================================

    /**
     * Calcula e exibe o total de litros colhidos em cada talhão.
     * Mesma estratégia de arrays paralelos do Relatório A.
     */
    public static void relatorioProducaoPorTalhao(
            Colheita[] colheitas,  int totalColheitas,
            Talhao[]   talhoes,   int totalTalhoes) {

        System.out.println("\n══════════════════════════════════════════════");
        System.out.println("  RELATÓRIO B — Total Produzido por Talhão");
        System.out.println("══════════════════════════════════════════════");

        String[] codigosVistos   = new String[MAX_GRUPOS];
        double[] totaisPorTalhao = new double[MAX_GRUPOS];
        int quantidadeGrupos = 0;

        for (int i = 0; i < totalColheitas; i++) {
            String cod    = colheitas[i].codigoTalhao;
            double litros = colheitas[i].quantidadeLitros;

            int posicao = encontrarPosicao(codigosVistos, quantidadeGrupos, cod);

            if (posicao >= 0) {
                totaisPorTalhao[posicao] += litros;
            } else {
                codigosVistos[quantidadeGrupos]   = cod;
                totaisPorTalhao[quantidadeGrupos] = litros;
                quantidadeGrupos++;
            }
        }

        System.out.printf("%-8s %-20s %15s%n", "Código", "Nome do Talhão", "Total (L)");
        System.out.println("─".repeat(46));

        double totalGeral = 0;

        for (int i = 0; i < quantidadeGrupos; i++) {
            Talhao t = GerenciadorTalhoes.buscarTalhao(talhoes, totalTalhoes, codigosVistos[i]);
            String nomeTalhao = (t != null) ? t.nome : "(desconhecido)";

            System.out.printf("%-8s %-20s %15.2f%n",
                    codigosVistos[i], nomeTalhao, totaisPorTalhao[i]);

            totalGeral += totaisPorTalhao[i];
        }

        System.out.println("─".repeat(46));
        System.out.printf("%-29s %15.2f%n", "TOTAL GERAL:", totalGeral);
    }

    // ================================================================
    // RELATÓRIO C — Comparação produção atual vs estimativa
    // ================================================================

    /**
     * Compara a produção real já colhida com a estimativa cadastrada em cada talhão.
     * Também mostra o percentual de atingimento da meta.
     */
    public static void relatorioComparacaoEstimativa(
            Colheita[] colheitas,  int totalColheitas,
            Talhao[]   talhoes,   int totalTalhoes) {

        System.out.println("\n══════════════════════════════════════════════════════");
        System.out.println("  RELATÓRIO C — Produção Atual vs Estimativa por Talhão");
        System.out.println("══════════════════════════════════════════════════════");

        // Primeiro, acumula a produção real por talhão (mesma lógica anterior)
        String[] codigosVistos   = new String[MAX_GRUPOS];
        double[] totaisPorTalhao = new double[MAX_GRUPOS];
        int quantidadeGrupos = 0;

        for (int i = 0; i < totalColheitas; i++) {
            String cod    = colheitas[i].codigoTalhao;
            double litros = colheitas[i].quantidadeLitros;

            int posicao = encontrarPosicao(codigosVistos, quantidadeGrupos, cod);

            if (posicao >= 0) {
                totaisPorTalhao[posicao] += litros;
            } else {
                codigosVistos[quantidadeGrupos]   = cod;
                totaisPorTalhao[quantidadeGrupos] = litros;
                quantidadeGrupos++;
            }
        }

        // Exibe comparação para cada talhão cadastrado
        System.out.printf("%-8s %-18s %12s %12s %10s %s%n",
                "Código", "Talhão", "Estimativa", "Colhido", "(%)", "Status");
        System.out.println("─".repeat(75));

        for (int i = 0; i < totalTalhoes; i++) {
            Talhao t = talhoes[i];

            // Procura o total colhido para este talhão
            double colhido = 0;
            int pos = encontrarPosicao(codigosVistos, quantidadeGrupos, t.codigo);
            if (pos >= 0) {
                colhido = totaisPorTalhao[pos];
            }

            // Calcula o percentual atingido
            double percentual = 0;
            if (t.estimativaLitros > 0) {
                percentual = (colhido / t.estimativaLitros) * 100;
            }

            // Define o status
            String status;
            if (colhido == 0) {
                status = "⬜ Não iniciado";
            } else if (percentual < 50) {
                status = "🔴 Abaixo de 50%";
            } else if (percentual < 100) {
                status = "🟡 Em andamento";
            } else {
                status = "🟢 Meta atingida!";
            }

            System.out.printf("%-8s %-18s %12.2f %12.2f %9.1f%% %s%n",
                    t.codigo, t.nome, t.estimativaLitros, colhido, percentual, status);
        }
    }

    // ================================================================
    // RELATÓRIO D — Total por local de descarregamento
    // ================================================================

    /**
     * Totaliza os litros enviados para cada local de descarregamento.
     * Como só existem 2 locais fixos, não precisamos de arrays paralelos —
     * apenas dois acumuladores.
     */
    public static void relatorioLocalDescarregamento(Colheita[] colheitas, int totalColheitas) {

        System.out.println("\n══════════════════════════════════════════════════════");
        System.out.println("  RELATÓRIO D — Total por Local de Descarregamento");
        System.out.println("══════════════════════════════════════════════════════");

        // Dois acumuladores simples (um para cada local)
        double totalTerreiroC  = 0;
        double totalSecadorM   = 0;

        // Percorre todas as colheitas e soma ao acumulador correto
        for (int i = 0; i < totalColheitas; i++) {
            String local  = colheitas[i].localDescarregamento;
            double litros = colheitas[i].quantidadeLitros;

            if (local.equals("Terreiro de Cimento")) {
                totalTerreiroC += litros;
            } else if (local.equals("Secador Mecânico")) {
                totalSecadorM += litros;
            }
        }

        double totalGeral = totalTerreiroC + totalSecadorM;

        // Exibe os resultados
        System.out.println();
        System.out.printf("  %-25s : %12.2f L%n", "Terreiro de Cimento", totalTerreiroC);
        System.out.printf("  %-25s : %12.2f L%n", "Secador Mecânico",    totalSecadorM);
        System.out.println("  " + "─".repeat(42));
        System.out.printf("  %-25s : %12.2f L%n", "TOTAL GERAL",         totalGeral);

        // Percentuais
        if (totalGeral > 0) {
            System.out.println();
            System.out.printf("  Terreiro de Cimento : %.1f%% do total%n",
                    (totalTerreiroC / totalGeral) * 100);
            System.out.printf("  Secador Mecânico    : %.1f%% do total%n",
                    (totalSecadorM  / totalGeral) * 100);
        }
    }

    // ================================================================
    // MÉTODO AUXILIAR — Busca posição em array de strings
    // ================================================================

    /**
     * Procura uma string em um array e retorna sua posição.
     *
     * Usado nos relatórios para verificar se já existe uma entrada
     * para determinada matrícula ou código de talhão.
     *
     * @param array  array de strings onde buscar
     * @param total  quantidade de elementos válidos no array
     * @param valor  valor a ser encontrado
     * @return índice onde foi encontrado, ou -1 se não encontrou
     */
    private static int encontrarPosicao(String[] array, int total, String valor) {
        for (int i = 0; i < total; i++) {
            if (array[i].equalsIgnoreCase(valor)) {
                return i; // encontrou na posição i
            }
        }
        return -1; // não encontrou
    }
}