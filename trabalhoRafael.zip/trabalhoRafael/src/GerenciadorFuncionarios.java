import java.util.Scanner;

/**
 * CLASSE: GerenciadorFuncionarios
 *
 * Contém todos os métodos relacionados ao cadastro e consulta de funcionários.
 *
 * Responsabilidades:
 *  - Exibir o menu de funcionários
 *  - Cadastrar novo funcionário (com validação de matrícula duplicada)
 *  - Listar todos os funcionários
 *  - Buscar um funcionário pela matrícula (usado também nas validações de colheita)
 */
public class GerenciadorFuncionarios {

    /**
     * Exibe o submenu de Funcionários e processa a escolha do usuário.
     *
     * @param funcionarios array com todos os funcionários carregados
     * @param totalFunc    array de 1 posição com o contador de funcionários
     * @param sc           Scanner para leitura do teclado
     */
    public static void menuFuncionarios(Funcionario[] funcionarios, int[] totalFunc, Scanner sc) {
        int opcao;

        do {
            // Exibe o submenu
            System.out.println("\n╔══════════════════════════════╗");
            System.out.println("║     GESTÃO DE FUNCIONÁRIOS    ║");
            System.out.println("╠══════════════════════════════╣");
            System.out.println("║ 1 - Cadastrar Funcionário     ║");
            System.out.println("║ 2 - Listar Funcionários       ║");
            System.out.println("║ 0 - Voltar ao Menu Principal  ║");
            System.out.println("╚══════════════════════════════╝");
            System.out.print("Opção: ");

            opcao = sc.nextInt();
            sc.nextLine(); // limpa o buffer do teclado

            switch (opcao) {
                case 1:
                    cadastrarFuncionario(funcionarios, totalFunc, sc);
                    break;
                case 2:
                    listarFuncionarios(funcionarios, totalFunc[0]);
                    break;
                case 0:
                    System.out.println("Voltando ao menu principal...");
                    break;
                default:
                    System.out.println("Opção inválida! Tente novamente.");
            }

        } while (opcao != 0); // fica no loop até o usuário escolher sair
    }

    /**
     * Cadastra um novo funcionário.
     *
     * Validações:
     *  - Verifica se a matrícula já existe (não permite duplicata)
     *  - Verifica se o tipo de contrato é válido ("Diarista" ou "Fixo")
     *  - Verifica se o array não está cheio (máximo 100)
     */
    public static void cadastrarFuncionario(Funcionario[] funcionarios, int[] totalFunc, Scanner sc) {

        // Verifica se ainda há espaço no array
        if (totalFunc[0] >= funcionarios.length) {
            System.out.println("Limite de funcionários atingido!");
            return;
        }

        System.out.println("\n--- CADASTRO DE FUNCIONÁRIO ---");

        // Leitura do nome
        System.out.print("Nome completo: ");
        String nome = sc.nextLine().trim();

        // Leitura e validação da matrícula
        System.out.print("Matrícula: ");
        String matricula = sc.nextLine().trim();

        // Verifica se já existe um funcionário com essa matrícula
        if (buscarFuncionario(funcionarios, totalFunc[0], matricula) != null) {
            System.out.println("ERRO: Já existe um funcionário com essa matrícula!");
            return;
        }

        // Leitura e validação do tipo de contrato
        System.out.println("Tipo de contrato:");
        System.out.println("  1 - Fixo");
        System.out.println("  2 - Diarista");
        System.out.print("Escolha: ");
        int tipoEscolha = sc.nextInt();
        sc.nextLine();

        String tipoContrato;
        if (tipoEscolha == 1) {
            tipoContrato = "Fixo";
        } else if (tipoEscolha == 2) {
            tipoContrato = "Diarista";
        } else {
            System.out.println("ERRO: Tipo de contrato inválido!");
            return;
        }

        // Cria o novo funcionário
        Funcionario novo = new Funcionario(nome, matricula, tipoContrato);

        // Adiciona no array na posição indicada pelo contador
        funcionarios[totalFunc[0]] = novo;
        totalFunc[0]++; // incrementa o contador

        // Salva no arquivo .txt para persistência
        Arquivos.salvarFuncionario(novo);

        System.out.println("✔ Funcionário cadastrado com sucesso!");
    }

    /**
     * Lista todos os funcionários cadastrados.
     * Percorre o array do índice 0 até totalFunc (exclusive).
     */
    public static void listarFuncionarios(Funcionario[] funcionarios, int totalFunc) {
        System.out.println("\n--- LISTA DE FUNCIONÁRIOS ---");

        if (totalFunc == 0) {
            System.out.println("Nenhum funcionário cadastrado.");
            return;
        }

        // Cabeçalho da tabela
        System.out.printf("%-5s %-25s %-12s %-12s%n", "Nº", "Nome", "Matrícula", "Contrato");
        System.out.println("─".repeat(57));

        // Percorre o array até o total de funcionários
        for (int i = 0; i < totalFunc; i++) {
            System.out.printf("%-5d %-25s %-12s %-12s%n",
                    (i + 1),
                    funcionarios[i].nome,
                    funcionarios[i].matricula,
                    funcionarios[i].tipoContrato
            );
        }
    }

    /**
     * Busca um funcionário pela matrícula.
     *
     * Percorre o array comparando cada matrícula.
     * Retorna o objeto Funcionario se encontrar, ou null se não encontrar.
     *
     * Esse método é usado:
     *  - Para validar antes de registrar uma colheita
     *  - Para evitar matrícula duplicada no cadastro
     *
     * @param funcionarios array de funcionários
     * @param totalFunc    quantidade de funcionários no array
     * @param matricula    matrícula que se deseja encontrar
     * @return Funcionario encontrado, ou null
     */
    public static Funcionario buscarFuncionario(Funcionario[] funcionarios, int totalFunc, String matricula) {
        for (int i = 0; i < totalFunc; i++) {
            // Compara ignorando maiúsculas/minúsculas
            if (funcionarios[i].matricula.equalsIgnoreCase(matricula)) {
                return funcionarios[i]; // encontrou!
            }
        }
        return null; // não encontrou
    }
}