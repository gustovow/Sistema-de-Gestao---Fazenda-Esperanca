/**
 * CLASSE: Colheita
 *
 * Representa um registro de colheita realizado na fazenda.
 * Cada colheita liga um funcionário, um talhão e um trator
 * a uma quantidade colhida e um local de descarregamento.
 *
 * Campos:
 *  - data                  : data da colheita (ex: "15/06/2025")
 *  - matriculaFuncionario  : matrícula do funcionário que realizou a colheita
 *  - codigoTalhao          : código do talhão onde foi colhido
 *  - placaTrator           : placa do trator usado
 *  - quantidadeLitros      : quantidade colhida em litros
 *  - localDescarregamento  : "Terreiro de Cimento" ou "Secador Mecânico"
 */
public class Colheita {

    // -------------------------------------------------------
    // ATRIBUTOS
    // -------------------------------------------------------
    String data;
    String matriculaFuncionario;
    String codigoTalhao;
    String placaTrator;
    double quantidadeLitros;
    String localDescarregamento;

    // -------------------------------------------------------
    // CONSTRUTOR
    // -------------------------------------------------------
    public Colheita(String data, String matriculaFuncionario, String codigoTalhao,
                    String placaTrator, double quantidadeLitros, String localDescarregamento) {
        this.data = data;
        this.matriculaFuncionario = matriculaFuncionario;
        this.codigoTalhao = codigoTalhao;
        this.placaTrator = placaTrator;
        this.quantidadeLitros = quantidadeLitros;
        this.localDescarregamento = localDescarregamento;
    }

    /**
     * Converte a colheita para linha de texto no formato:
     * data;matricula;codigoTalhao;placa;litros;local
     *
     * Usado para salvar no arquivo colheitas.txt
     */
    public String paraTexto() {
        return data + ";" + matriculaFuncionario + ";" + codigoTalhao + ";"
                + placaTrator + ";" + quantidadeLitros + ";" + localDescarregamento;
    }
}