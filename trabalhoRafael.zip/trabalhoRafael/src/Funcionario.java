/**
 * CLASSE: Funcionario
 *
 * Representa um funcionário da Fazenda Esperança.
 * Esta é uma classe simples de dados (sem lógica complexa),
 * contendo apenas os campos e métodos de acesso (getters/setters básicos).
 *
 * Campos:
 *  - nome       : nome completo do funcionário
 *  - matricula  : código único de identificação
 *  - tipoContrato: "Diarista" ou "Fixo"
 */
public class Funcionario {

    // -------------------------------------------------------
    // ATRIBUTOS (campos de dados do funcionário)
    // -------------------------------------------------------
    String nome;
    String matricula;
    String tipoContrato; // Valores válidos: "Diarista" ou "Fixo"

    // -------------------------------------------------------
    // CONSTRUTOR: inicializa todos os campos de uma vez
    // -------------------------------------------------------
    public Funcionario(String nome, String matricula, String tipoContrato) {
        this.nome = nome;
        this.matricula = matricula;
        this.tipoContrato = tipoContrato;
    }

    /**
     * Converte o funcionário para uma linha de texto no formato:
     * nome;matricula;tipoContrato
     *
     * Esse formato é usado para SALVAR no arquivo .txt
     */
    public String paraTexto() {
        return nome + ";" + matricula + ";" + tipoContrato;
    }
}