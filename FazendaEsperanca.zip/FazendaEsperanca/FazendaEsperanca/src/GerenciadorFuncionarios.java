public class GerenciadorFuncionarios {

    public static void menuFuncionarios() {
        int opcao;
        do {
            System.out.println();
            System.out.println("--- GESTAO DE FUNCIONARIOS ---");
            System.out.println("1 - Cadastrar");
            System.out.println("2 - Listar");
            System.out.println("0 - Voltar");
            System.out.print("Opcao: ");
            opcao = Main.sc.nextInt();
            Main.sc.nextLine();

            if (opcao == 1) cadastrarFuncionario();
            else if (opcao == 2) listarFuncionarios();
            else if (opcao == 0) System.out.println("Voltando...");
            else System.out.println("Opcao invalida!");
        } while (opcao != 0);
    }

    public static void cadastrarFuncionario() {
        if (Main.totalFuncionarios >= Main.funcionarios.length) {
            System.out.println("Limite atingido!");
            return;
        }

        System.out.println();
        System.out.println("--- CADASTRO DE FUNCIONARIO ---");
        System.out.print("Nome: ");
        String nome = Main.sc.nextLine().trim();

        System.out.print("Matricula: ");
        String matricula = Main.sc.nextLine().trim();

        if (buscarFuncionario(matricula) != null) {
            System.out.println("ERRO: matricula ja cadastrada!");
            return;
        }

        System.out.println("Tipo de contrato:");
        System.out.println("  1 - Fixo");
        System.out.println("  2 - Diarista");
        System.out.print("Escolha: ");
        int t = Main.sc.nextInt();
        Main.sc.nextLine();

        String tipo;
        if (t == 1) tipo = "Fixo";
        else if (t == 2) tipo = "Diarista";
        else { System.out.println("ERRO: tipo invalido!"); return; }

        Main.funcionarios[Main.totalFuncionarios] = new Funcionario();
        Main.funcionarios[Main.totalFuncionarios].nome = nome;
        Main.funcionarios[Main.totalFuncionarios].matricula = matricula;
        Main.funcionarios[Main.totalFuncionarios].tipoContrato = tipo;
        Main.totalFuncionarios++;

        Arquivos.salvarFuncionarios(Main.funcionarios, Main.totalFuncionarios);
        System.out.println("Funcionario cadastrado!");
    }

    public static void listarFuncionarios() {
        System.out.println();
        System.out.println("--- FUNCIONARIOS ---");
        if (Main.totalFuncionarios == 0) {
            System.out.println("Nenhum funcionario.");
            return;
        }
        for (int i = 0; i < Main.totalFuncionarios; i++) {
            System.out.println((i+1) + ") Mat: " + Main.funcionarios[i].matricula
                    + " | " + Main.funcionarios[i].nome
                    + " | " + Main.funcionarios[i].tipoContrato);
        }
    }

    public static Funcionario buscarFuncionario(String matricula) {
        for (int i = 0; i < Main.totalFuncionarios; i++) {
            if (Main.funcionarios[i].matricula.equals(matricula)) {
                return Main.funcionarios[i];
            }
        }
        return null;
    }
}