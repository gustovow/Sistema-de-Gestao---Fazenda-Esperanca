public class Colheita {
    public String data;
    public String matriculaFuncionario;
    public String codigoTalhao;
    public String placaTrator;
    public double quantidadeLitros;
    public String localDescarregamento;
}