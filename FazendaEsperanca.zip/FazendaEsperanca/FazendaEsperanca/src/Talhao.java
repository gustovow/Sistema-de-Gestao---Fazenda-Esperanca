public class Talhao {
    public String codigo;
    public String nome;
    public String variedadeCafe;
    public double estimativaLitros;
}