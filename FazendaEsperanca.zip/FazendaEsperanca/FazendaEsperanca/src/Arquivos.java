import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;

public class Arquivos {

    public static final String ARQ_FUNCIONARIOS = "funcionarios.txt";
    public static final String ARQ_TALHOES = "talhoes.txt";
    public static final String ARQ_FROTA = "frota.txt";
    public static final String ARQ_COLHEITAS = "colheitas.txt";

    public static void salvarFuncionarios(Funcionario[] f, int total) {
        try {
            FileWriter arq = new FileWriter(ARQ_FUNCIONARIOS);
            PrintWriter g = new PrintWriter(arq);
            for (int i = 0; i < total; i++) {
                g.println(f[i].nome + ";" + f[i].matricula + ";" + f[i].tipoContrato);
            }
            g.close();
        } catch (Exception e) {
            System.out.println("Erro ao salvar funcionarios: " + e.getMessage());
        }
    }

    public static void salvarTalhoes(Talhao[] t, int total) {
        try {
            FileWriter arq = new FileWriter(ARQ_TALHOES);
            PrintWriter g = new PrintWriter(arq);
            for (int i = 0; i < total; i++) {
                g.println(t[i].codigo + ";" + t[i].nome + ";" + t[i].variedadeCafe + ";" + t[i].estimativaLitros);
            }
            g.close();
        } catch (Exception e) {
            System.out.println("Erro ao salvar talhoes: " + e.getMessage());
        }
    }

    public static void salvarFrota(Trator[] fr, int total) {
        try {
            FileWriter arq = new FileWriter(ARQ_FROTA);
            PrintWriter g = new PrintWriter(arq);
            for (int i = 0; i < total; i++) {
                g.println(fr[i].placa + ";" + fr[i].capacidadeLitros);
            }
            g.close();
        } catch (Exception e) {
            System.out.println("Erro ao salvar frota: " + e.getMessage());
        }
    }

    public static void salvarColheitas(Colheita[] c, int total) {
        try {
            FileWriter arq = new FileWriter(ARQ_COLHEITAS);
            PrintWriter g = new PrintWriter(arq);
            for (int i = 0; i < total; i++) {
                g.println(c[i].data + ";" + c[i].matriculaFuncionario + ";"
                        + c[i].codigoTalhao + ";" + c[i].placaTrator + ";"
                        + c[i].quantidadeLitros + ";" + c[i].localDescarregamento);
            }
            g.close();
        } catch (Exception e) {
            System.out.println("Erro ao salvar colheitas: " + e.getMessage());
        }
    }

    public static int carregarFuncionarios(Funcionario[] f) {
        int c = 0;
        try {
            Scanner l = new Scanner(new File(ARQ_FUNCIONARIOS));
            while (l.hasNextLine() && c < f.length) {
                String linha = l.nextLine();
                if (linha.length() == 0) continue;
                String[] d = linha.split(";");
                if (d.length == 3) {
                    f[c] = new Funcionario();
                    f[c].nome = d[0];
                    f[c].matricula = d[1];
                    f[c].tipoContrato = d[2];
                    c++;
                }
            }
            l.close();
        } catch (Exception e) {}
        return c;
    }

    public static int carregarTalhoes(Talhao[] t) {
        int c = 0;
        try {
            Scanner l = new Scanner(new File(ARQ_TALHOES));
            while (l.hasNextLine() && c < t.length) {
                String linha = l.nextLine();
                if (linha.length() == 0) continue;
                String[] d = linha.split(";");
                if (d.length == 4) {
                    t[c] = new Talhao();
                    t[c].codigo = d[0];
                    t[c].nome = d[1];
                    t[c].variedadeCafe = d[2];
                    t[c].estimativaLitros = Double.parseDouble(d[3]);
                    c++;
                }
            }
            l.close();
        } catch (Exception e) {}
        return c;
    }

    public static int carregarFrota(Trator[] fr) {
        int c = 0;
        try {
            Scanner l = new Scanner(new File(ARQ_FROTA));
            while (l.hasNextLine() && c < fr.length) {
                String linha = l.nextLine();
                if (linha.length() == 0) continue;
                String[] d = linha.split(";");
                if (d.length == 2) {
                    fr[c] = new Trator();
                    fr[c].placa = d[0];
                    fr[c].capacidadeLitros = Double.parseDouble(d[1]);
                    c++;
                }
            }
            l.close();
        } catch (Exception e) {}
        return c;
    }

    public static int carregarColheitas(Colheita[] co) {
        int c = 0;
        try {
            Scanner l = new Scanner(new File(ARQ_COLHEITAS));
            while (l.hasNextLine() && c < co.length) {
                String linha = l.nextLine();
                if (linha.length() == 0) continue;
                String[] d = linha.split(";");
                if (d.length == 6) {
                    co[c] = new Colheita();
                    co[c].data = d[0];
                    co[c].matriculaFuncionario = d[1];
                    co[c].codigoTalhao = d[2];
                    co[c].placaTrator = d[3];
                    co[c].quantidadeLitros = Double.parseDouble(d[4]);
                    co[c].localDescarregamento = d[5];
                    c++;
                }
            }
            l.close();
        } catch (Exception e) {}
        return c;
    }
}