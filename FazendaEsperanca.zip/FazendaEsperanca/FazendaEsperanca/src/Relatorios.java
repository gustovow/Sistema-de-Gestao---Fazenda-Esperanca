public class Relatorios {

    public static final int MAX_GRUPOS = 100;
    public static final String LINHA = "------------------------------------------------------------";

    public static void menuRelatorios() {
        if (Main.totalColheitas == 0) {
            System.out.println("Sem colheitas para relatorios.");
            return;
        }

        int op;
        do {
            System.out.println();
            System.out.println("--- RELATORIOS ---");
            System.out.println("A - Acerto da Quinzena (litros por funcionario)");
            System.out.println("B - Fechamento do Talhao (producao vs estimativa)");
            System.out.println("C - Secagem (Terreiro vs Secador)");
            System.out.println("T - Exibir TODOS");
            System.out.println("0 - Voltar");
            System.out.print("Opcao: ");
            String opStr = Main.sc.nextLine().trim().toUpperCase();

            if (opStr.equals("A")) { relatorioAcertoQuinzena(); op = 1; }
            else if (opStr.equals("B")) { relatorioFechamentoTalhao(); op = 1; }
            else if (opStr.equals("C")) { relatorioSecagem(); op = 1; }
            else if (opStr.equals("T")) {
                relatorioAcertoQuinzena();
                relatorioFechamentoTalhao();
                relatorioSecagem();
                op = 1;
            }
            else if (opStr.equals("0")) { System.out.println("Voltando..."); op = 0; }
            else { System.out.println("Opcao invalida!"); op = 1; }
        } while (op != 0);
    }

    // RELATORIO A — Acerto da Quinzena
    public static void relatorioAcertoQuinzena() {
        System.out.println();
        System.out.println(LINHA);
        System.out.println("  A - ACERTO DA QUINZENA (Litros por Funcionario)");
        System.out.println(LINHA);

        String[] mats = new String[MAX_GRUPOS];
        double[] tot = new double[MAX_GRUPOS];
        int q = 0;

        for (int i = 0; i < Main.totalColheitas; i++) {
            String m = Main.colheitas[i].matriculaFuncionario;
            int p = posicao(mats, q, m);
            if (p >= 0) tot[p] += Main.colheitas[i].quantidadeLitros;
            else { mats[q] = m; tot[q] = Main.colheitas[i].quantidadeLitros; q++; }
        }

        double geral = 0;
        for (int i = 0; i < q; i++) {
            Funcionario f = GerenciadorFuncionarios.buscarFuncionario(mats[i]);
            String nome = (f != null) ? f.nome : "(desconhecido)";
            String contrato = (f != null) ? f.tipoContrato : "-";
            System.out.println("  Mat: " + mats[i] + " | " + nome + " (" + contrato + ") | " + tot[i] + " L");
            geral += tot[i];
        }
        System.out.println(LINHA);
        System.out.println("  TOTAL GERAL: " + geral + " L");
    }

    // RELATORIO B — Fechamento do Talhao
    public static void relatorioFechamentoTalhao() {
        System.out.println();
        System.out.println(LINHA);
        System.out.println("  B - FECHAMENTO DO TALHAO");
        System.out.println(LINHA);

        String[] cods = new String[MAX_GRUPOS];
        double[] tot = new double[MAX_GRUPOS];
        int q = 0;
        for (int i = 0; i < Main.totalColheitas; i++) {
            String c = Main.colheitas[i].codigoTalhao;
            int p = posicao(cods, q, c);
            if (p >= 0) tot[p] += Main.colheitas[i].quantidadeLitros;
            else { cods[q] = c; tot[q] = Main.colheitas[i].quantidadeLitros; q++; }
        }

        for (int i = 0; i < Main.totalTalhoes; i++) {
            Talhao t = Main.talhoes[i];
            double colh = 0;
            int p = posicao(cods, q, t.codigo);
            if (p >= 0) colh = tot[p];

            double pct = 0;
            if (t.estimativaLitros > 0) pct = (colh / t.estimativaLitros) * 100;

            String st;
            if (colh == 0) st = "NAO INICIADO";
            else if (pct < 50) st = "ABAIXO 50%";
            else if (pct < 100) st = "EM ANDAMENTO";
            else st = "META ATINGIDA";

            System.out.println("  " + t.codigo + " - " + t.nome
                    + " | Estim: " + t.estimativaLitros + " L"
                    + " | Colh: " + colh + " L"
                    + " | " + String.format("%.1f", pct) + "% | " + st);
        }
    }

    // RELATORIO C — Secagem
    public static void relatorioSecagem() {
        System.out.println();
        System.out.println(LINHA);
        System.out.println("  C - SECAGEM (Terreiro vs Secador)");
        System.out.println(LINHA);

        double terr = 0, sec = 0;
        for (int i = 0; i < Main.totalColheitas; i++) {
            if (Main.colheitas[i].localDescarregamento.equals("Terreiro de Cimento"))
                terr += Main.colheitas[i].quantidadeLitros;
            else if (Main.colheitas[i].localDescarregamento.equals("Secador Mecanico"))
                sec += Main.colheitas[i].quantidadeLitros;
        }
        double total = terr + sec;
        System.out.println("  Terreiro de Cimento: " + terr + " L");
        System.out.println("  Secador Mecanico:    " + sec + " L");
        System.out.println(LINHA);
        System.out.println("  TOTAL: " + total + " L");
        if (total > 0) {
            System.out.println("  Terreiro: " + String.format("%.1f", (terr/total)*100) + "%");
            System.out.println("  Secador:  " + String.format("%.1f", (sec/total)*100) + "%");
        }
    }

    private static int posicao(String[] arr, int total, String valor) {
        for (int i = 0; i < total; i++) {
            if (arr[i].equals(valor)) return i;
        }
        return -1;
    }
}