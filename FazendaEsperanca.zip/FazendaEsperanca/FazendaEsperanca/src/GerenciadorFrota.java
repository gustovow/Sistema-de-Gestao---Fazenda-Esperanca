public class GerenciadorFrota {

    public static void menuFrota() {
        int opcao;
        do {
            System.out.println();
            System.out.println("--- GESTAO DA FROTA ---");
            System.out.println("1 - Cadastrar Trator");
            System.out.println("2 - Listar Frota");
            System.out.println("0 - Voltar");
            System.out.print("Opcao: ");
            opcao = Main.sc.nextInt();
            Main.sc.nextLine();

            if (opcao == 1) cadastrarTrator();
            else if (opcao == 2) listarFrota();
            else if (opcao == 0) System.out.println("Voltando...");
            else System.out.println("Opcao invalida!");
        } while (opcao != 0);
    }

    public static void cadastrarTrator() {
        if (Main.totalFrota >= Main.frota.length) {
            System.out.println("Limite atingido!");
            return;
        }

        System.out.println();
        System.out.println("--- CADASTRO DE TRATOR ---");
        System.out.print("Placa: ");
        String placa = Main.sc.nextLine().trim().toUpperCase();

        if (buscarTrator(placa) != null) {
            System.out.println("ERRO: placa ja cadastrada!");
            return;
        }

        System.out.print("Capacidade da carreta (litros): ");
        double cap = Main.sc.nextDouble();
        Main.sc.nextLine();

        if (cap <= 0) {
            System.out.println("ERRO: capacidade deve ser > 0!");
            return;
        }

        Main.frota[Main.totalFrota] = new Trator();
        Main.frota[Main.totalFrota].placa = placa;
        Main.frota[Main.totalFrota].capacidadeLitros = cap;
        Main.totalFrota++;

        Arquivos.salvarFrota(Main.frota, Main.totalFrota);
        System.out.println("Trator cadastrado!");
    }

    public static void listarFrota() {
        System.out.println();
        System.out.println("--- FROTA ---");
        if (Main.totalFrota == 0) {
            System.out.println("Nenhum trator.");
            return;
        }
        for (int i = 0; i < Main.totalFrota; i++) {
            System.out.println((i+1) + ") Placa: " + Main.frota[i].placa
                    + " | Cap: " + Main.frota[i].capacidadeLitros + " L");
        }
    }

    public static Trator buscarTrator(String placa) {
        for (int i = 0; i < Main.totalFrota; i++) {
            if (Main.frota[i].placa.equals(placa)) {
                return Main.frota[i];
            }
        }
        return null;
    }
}