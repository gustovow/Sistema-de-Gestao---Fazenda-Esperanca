public class GerenciadorTalhoes {

    public static void menuTalhoes() {
        int opcao;
        do {
            System.out.println();
            System.out.println("--- GESTAO DE TALHOES ---");
            System.out.println("1 - Cadastrar");
            System.out.println("2 - Listar");
            System.out.println("0 - Voltar");
            System.out.print("Opcao: ");
            opcao = Main.sc.nextInt();
            Main.sc.nextLine();

            if (opcao == 1) cadastrarTalhao();
            else if (opcao == 2) listarTalhoes();
            else if (opcao == 0) System.out.println("Voltando...");
            else System.out.println("Opcao invalida!");
        } while (opcao != 0);
    }

    public static void cadastrarTalhao() {
        if (Main.totalTalhoes >= Main.talhoes.length) {
            System.out.println("Limite atingido!");
            return;
        }

        System.out.println();
        System.out.println("--- CADASTRO DE TALHAO ---");
        System.out.print("Codigo (ex: T01): ");
        String codigo = Main.sc.nextLine().trim().toUpperCase();

        if (buscarTalhao(codigo) != null) {
            System.out.println("ERRO: codigo ja cadastrado!");
            return;
        }

        System.out.print("Nome: ");
        String nome = Main.sc.nextLine().trim();
        System.out.print("Variedade (Catuai, Mundo Novo, etc.): ");
        String variedade = Main.sc.nextLine().trim();
        System.out.print("Estimativa de producao (litros): ");
        double est = Main.sc.nextDouble();
        Main.sc.nextLine();

        if (est <= 0) {
            System.out.println("ERRO: estimativa deve ser > 0!");
            return;
        }

        Main.talhoes[Main.totalTalhoes] = new Talhao();
        Main.talhoes[Main.totalTalhoes].codigo = codigo;
        Main.talhoes[Main.totalTalhoes].nome = nome;
        Main.talhoes[Main.totalTalhoes].variedadeCafe = variedade;
        Main.talhoes[Main.totalTalhoes].estimativaLitros = est;
        Main.totalTalhoes++;

        Arquivos.salvarTalhoes(Main.talhoes, Main.totalTalhoes);
        System.out.println("Talhao cadastrado!");
    }

    public static void listarTalhoes() {
        System.out.println();
        System.out.println("--- TALHOES ---");
        if (Main.totalTalhoes == 0) {
            System.out.println("Nenhum talhao.");
            return;
        }
        for (int i = 0; i < Main.totalTalhoes; i++) {
            System.out.println(Main.talhoes[i].codigo + " - " + Main.talhoes[i].nome
                    + " | " + Main.talhoes[i].variedadeCafe
                    + " | Estim: " + Main.talhoes[i].estimativaLitros + " L");
        }
    }

    public static Talhao buscarTalhao(String codigo) {
        for (int i = 0; i < Main.totalTalhoes; i++) {
            if (Main.talhoes[i].codigo.equals(codigo)) {
                return Main.talhoes[i];
            }
        }
        return null;
    }
}