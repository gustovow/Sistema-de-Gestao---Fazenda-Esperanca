public class GerenciadorColheitas {

    public static void menuColheitas() {
        int opcao;
        do {
            System.out.println();
            System.out.println("--- REGISTRO DE COLHEITA ---");
            System.out.println("1 - Registrar Colheita");
            System.out.println("2 - Listar Colheitas");
            System.out.println("0 - Voltar");
            System.out.print("Opcao: ");
            opcao = Main.sc.nextInt();
            Main.sc.nextLine();

            if (opcao == 1) registrarColheita();
            else if (opcao == 2) listarColheitas();
            else if (opcao == 0) System.out.println("Voltando...");
            else System.out.println("Opcao invalida!");
        } while (opcao != 0);
    }

    public static void registrarColheita() {
        if (Main.totalColheitas >= Main.colheitas.length) {
            System.out.println("Limite atingido!");
            return;
        }

        System.out.println();
        System.out.println("--- NOVA COLHEITA ---");

        System.out.print("Data (dd/mm/aaaa): ");
        String data = Main.sc.nextLine().trim();

        // VALIDACAO 1: funcionario existe?
        System.out.print("Matricula do funcionario: ");
        String matricula = Main.sc.nextLine().trim();
        Funcionario func = GerenciadorFuncionarios.buscarFuncionario(matricula);
        if (func == null) {
            System.out.println("ERRO: funcionario nao encontrado!");
            return;
        }
        System.out.println("  -> " + func.nome);

        // VALIDACAO 2: talhao existe?
        System.out.print("Codigo do talhao: ");
        String codTalhao = Main.sc.nextLine().trim().toUpperCase();
        Talhao talhao = GerenciadorTalhoes.buscarTalhao(codTalhao);
        if (talhao == null) {
            System.out.println("ERRO: talhao nao encontrado!");
            return;
        }
        System.out.println("  -> " + talhao.nome + " | " + talhao.variedadeCafe);

        // VALIDACAO 3: trator existe?
        System.out.print("Placa do trator: ");
        String placa = Main.sc.nextLine().trim().toUpperCase();
        Trator trator = GerenciadorFrota.buscarTrator(placa);
        if (trator == null) {
            System.out.println("ERRO: trator nao encontrado!");
            return;
        }
        System.out.println("  -> Cap: " + trator.capacidadeLitros + " L");

        // VALIDACAO 4: litros nao excedem capacidade?
        System.out.print("Quantidade (litros): ");
        double litros = Main.sc.nextDouble();
        Main.sc.nextLine();

        if (litros <= 0) {
            System.out.println("ERRO: quantidade deve ser > 0!");
            return;
        }
        if (litros > trator.capacidadeLitros) {
            System.out.println("ERRO: " + litros + " L excede capacidade do trator (" + trator.capacidadeLitros + " L)!");
            return;
        }

        System.out.println("Destino:");
        System.out.println("  1 - Terreiro de Cimento");
        System.out.println("  2 - Secador Mecanico");
        System.out.print("Escolha: ");
        int d = Main.sc.nextInt();
        Main.sc.nextLine();

        String destino;
        if (d == 1) destino = "Terreiro de Cimento";
        else if (d == 2) destino = "Secador Mecanico";
        else { System.out.println("ERRO: destino invalido!"); return; }

        Main.colheitas[Main.totalColheitas] = new Colheita();
        Main.colheitas[Main.totalColheitas].data = data;
        Main.colheitas[Main.totalColheitas].matriculaFuncionario = matricula;
        Main.colheitas[Main.totalColheitas].codigoTalhao = codTalhao;
        Main.colheitas[Main.totalColheitas].placaTrator = placa;
        Main.colheitas[Main.totalColheitas].quantidadeLitros = litros;
        Main.colheitas[Main.totalColheitas].localDescarregamento = destino;
        Main.totalColheitas++;

        Arquivos.salvarColheitas(Main.colheitas, Main.totalColheitas);
        System.out.println("Colheita registrada e salva no arquivo!");

        verificarAlerta(codTalhao, talhao);
    }

    // FUNCIONALIDADE DIFERENCIAL: Alerta de Talhao Esgotado
    public static void verificarAlerta(String codTalhao, Talhao talhao) {
        double total = 0;
        for (int i = 0; i < Main.totalColheitas; i++) {
            if (Main.colheitas[i].codigoTalhao.equals(codTalhao)) {
                total += Main.colheitas[i].quantidadeLitros;
            }
        }
        double pct = 0;
        if (talhao.estimativaLitros > 0) {
            pct = (total / talhao.estimativaLitros) * 100;
        }
        if (pct >= 100) {
            System.out.println();
            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            System.out.println("  ALERTA: Talhao " + codTalhao + " ULTRAPASSOU a estimativa!");
            System.out.println("  Colhido: " + total + " L | Estimado: " + talhao.estimativaLitros + " L");
            System.out.println("  Percentual: " + String.format("%.1f", pct) + "%");
            System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        } else if (pct >= 90) {
            System.out.println();
            System.out.println("*** ATENCAO: Talhao " + codTalhao + " ja atingiu "
                    + String.format("%.1f", pct) + "% da estimativa! ***");
        }
    }

    public static void listarColheitas() {
        System.out.println();
        System.out.println("--- COLHEITAS ---");
        if (Main.totalColheitas == 0) {
            System.out.println("Nenhuma colheita.");
            return;
        }
        for (int i = 0; i < Main.totalColheitas; i++) {
            System.out.println((i+1) + ") " + Main.colheitas[i].data
                    + " | Mat: " + Main.colheitas[i].matriculaFuncionario
                    + " | Talhao: " + Main.colheitas[i].codigoTalhao
                    + " | Placa: " + Main.colheitas[i].placaTrator
                    + " | " + Main.colheitas[i].quantidadeLitros + " L"
                    + " | " + Main.colheitas[i].localDescarregamento);
        }
    }
}