import java.util.Scanner;

public class Main {
    public static final int MAX_FUNCIONARIOS = 100;
    public static final int MAX_TALHOES = 100;
    public static final int MAX_FROTA = 100;
    public static final int MAX_COLHEITAS = 1000;

    public static Funcionario[] funcionarios = new Funcionario[MAX_FUNCIONARIOS];
    public static Talhao[] talhoes = new Talhao[MAX_TALHOES];
    public static Trator[] frota = new Trator[MAX_FROTA];
    public static Colheita[] colheitas = new Colheita[MAX_COLHEITAS];

    public static int totalFuncionarios = 0;
    public static int totalTalhoes = 0;
    public static int totalFrota = 0;
    public static int totalColheitas = 0;

    public static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Carregando dados...");
        totalFuncionarios = Arquivos.carregarFuncionarios(funcionarios);
        totalTalhoes = Arquivos.carregarTalhoes(talhoes);
        totalFrota = Arquivos.carregarFrota(frota);
        totalColheitas = Arquivos.carregarColheitas(colheitas);

        System.out.println("  " + totalFuncionarios + " funcionario(s)");
        System.out.println("  " + totalTalhoes + " talhao(oes)");
        System.out.println("  " + totalFrota + " trator(es)");
        System.out.println("  " + totalColheitas + " colheita(s)");

        int opcao;
        do {
            System.out.println();
            System.out.println("==========================================");
            System.out.println("     FAZENDA ESPERANCA - SISTEMA");
            System.out.println("==========================================");
            System.out.println("  1 - Gestao de Funcionarios");
            System.out.println("  2 - Gestao de Talhoes");
            System.out.println("  3 - Gestao da Frota");
            System.out.println("  4 - Registro de Colheita");
            System.out.println("  5 - Relatorios");
            System.out.println("  0 - Sair");
            System.out.println("==========================================");
            System.out.print("Opcao: ");
            opcao = sc.nextInt();
            sc.nextLine();

            if (opcao == 1) GerenciadorFuncionarios.menuFuncionarios();
            else if (opcao == 2) GerenciadorTalhoes.menuTalhoes();
            else if (opcao == 3) GerenciadorFrota.menuFrota();
            else if (opcao == 4) GerenciadorColheitas.menuColheitas();
            else if (opcao == 5) Relatorios.menuRelatorios();
            else if (opcao == 0) System.out.println("Encerrando...");
            else System.out.println("Opcao invalida!");
        } while (opcao != 0);

        sc.close();
    }
}